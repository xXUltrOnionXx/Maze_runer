camera = {x = 0, y = 0, scaleX = 1, scaleY = 1, rotation = 0}
function camera:set()
  love.graphics.push()
  love.graphics.rotate(-self.rotation)
  love.graphics.scale(1 / self.scaleX, 1 / self.scaleY)
  love.graphics.translate(-self.x, -self.y)
end
function camera:unset()
  love.graphics.pop()
end
function camera:setPosition(px, py)
  self.x = math.max(0, math.min(px - love.graphics.getWidth() / 2, backgroundWidth - love.graphics.getWidth()))
  self.y = math.max(0, math.min(py - love.graphics.getHeight() / 2, backgroundHeight - love.graphics.getHeight()))
end
function camera:getX() return love.mouse.getX() * self.scaleX + self.x end
function camera:getY() return love.mouse.getY() * self.scaleY + self.y end