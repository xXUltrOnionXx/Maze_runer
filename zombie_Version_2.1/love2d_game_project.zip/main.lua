require "camera"
require "draw"
require "mouse_pressed"
require "update"
require "player_mouse_angle"
require "object_collider"

systemMsg = ""

function terminalPrint(message)
   systemMsg = message
end

function love.load()
    terminalPrint("Konsole gestartet.")
    wf = require 'windfield'
    world = wf.newWorld(0, 0, false)
    world:addCollisionClass('Solid')

    sprites = {}
    sprites.background = love.graphics.newImage('sprites/background_with_walls.png')
    sprites.player = love.graphics.newImage('sprites/player.png')
    sprites.bullet = love.graphics.newImage('sprites/bullet.png')
    sprites.fireball = love.graphics.newImage('sprites/fireball.png')
    sprites.zombie = love.graphics.newImage('sprites/zombie.png')
    sprites.resized_Holz_wand_vertic_mini = love.graphics.newImage('sprites/resized_Holz_wand_vertic_mini.png')

    local Grid = require("libs.jumper.grid")
    local Pathfinder = require("libs.jumper.pathfinder")
    local map = require("map")

    local grid = Grid(map)
    pathfinder = Pathfinder(grid, 'ASTAR', 0)
    pathfinder:setMode('ORTHOGONAL')

    walls = {}
    create_wall_colliders(walls)

    player = {
        x = love.graphics.getWidth() / 2,
        y = love.graphics.getHeight() / 2,
        speed = 200,
        hp = 100,
        collider = world:newRectangleCollider(385, 287, sprites.player:getWidth(), sprites.player:getHeight())
    }

    zombies, bullets, Fireballs = {}, {}, {}
    Fireball_cost, gameState = 15, 1
    maxTime, timer, score = 2, 2, 0
    myFont, logFont = love.graphics.newFont(40), love.graphics.newFont(12)
end

function love.keypressed(key)
  if key == "return" and gameState == 1 then
    gameState = 2
    timer = maxTime
    score = 0
  end
end